// Classe ABB para demonstrar a inserção, busca, remoção, atravessamentos etc.
// em uma Árvore Binária de Busca (ABB).
// Ledón, 2016/2017; Amilton Souza Martha, 2015/2017.
package testa_abb;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Stack;

class ABB<E extends Comparable<E>> {  // Árvore Binária de Busca 

    private Node raiz;

    public ABB() {
        raiz = null;
    }

    public boolean isEmpty() {
        return (raiz == null);
    }

    //Configura a raiz da árvore
    public void setRaiz(Node araiz) {
        raiz = araiz;
    }

    public Node getRaiz() {
        return raiz;
    }

    public E inserir(E valor) {
        try {
            Node novo = new Node(valor);
            this.inserir(novo, raiz);
        } catch (Exception exMemoria) {
            return null;
        }   // memória insuficiente
        return (valor);
    }

    private Node inserir(Node novo, Node anterior) {
        if (raiz == null) {    // ou if(isEmpty())
            raiz = novo;  // ou setRaiz(novo);
            return raiz;
        }
        if (anterior == null) {
            return novo; // chegou em uma folha
        } else {
            if (novo.getValue().compareTo(anterior.getValue()) < 0) {
                anterior.setFilhoEsquerdo(inserir(novo, anterior.getFilhoEsquerdo()));
            } else {
                anterior.setFilhoDireito(inserir(novo, anterior.getFilhoDireito()));
            }
            return anterior;
        }
    }

    public void preOrdem(Node no) {
        if (no != null) {
            System.out.print(no.getValue() + "   ");
            preOrdem(no.getFilhoEsquerdo());
            preOrdem(no.getFilhoDireito());
        }
    }

    private int compara(Object ob1, Object ob2) {
        return ((Comparable) ob1).compareTo(((Comparable) ob2));
    }

    public E insert(E valor) { // implementação iterativa da inserção na ABB
        Node novoNodo;
        try {
            novoNodo = new Node(valor);
        } catch (Exception ex) {
            return null;
        } // memória insuficiente
        if (isEmpty()) {
            raiz = novoNodo; // se a ABB estiver vazia, inserimos na raiz 
        } else {
            Node atual = raiz;  // começamos procurar pela raiz      
            Node pai;
            while (true) {  // ciclo que só será interrompido ao acontecer a inserção (break interno)
                pai = atual;
                if (compara(valor, atual.getValue()) < 0) { // verificamos se devemos ir para a esquerda
                    atual = atual.getFilhoEsquerdo();
                    if (atual == null) {  // inserir à esquerda
                        pai.setFilhoEsquerdo(novoNodo);
                        break;
                    }
                } else { // ou ir para direita
                    atual = atual.getFilhoDireito();
                    if (atual == null) { // inserir a direita
                        pai.setFilhoDireito(novoNodo);
                        break;
                    }
                }
            }
        }
        return valor;
    }

    ArrayList<Aluno> a = new ArrayList<>();

    public void listaAluno(Aluno al) {  //Add na lista e filtrar

        if (al.getSexo() == "F") {
            a.add(al);

        }
    }
    
    public void calcularMedia(){
        
        float media = 0;
        float media1 = 0;
        float cont = 0;
        
        for (int i = 0; i < a.size(); i++) {
            
            media1+= a.get(i).getMedia();
            cont++;
            
            media = media1 / cont;
        }
        System.out.println(media);
    }
    
    public void preOrdemNaoRecursivo(Node raiz, Aluno aluno) {
        if (isEmpty()) {
            System.out.println("A árvore ABB está vazia");
            return;
        }
        Stack pi;
        Node p;
        pi = new Stack();
        pi.push(raiz);
        while (!pi.isEmpty()) {
            p = (Node) pi.pop();
            System.out.print("\n" + p.getValue() + "   ");
            if (p.getFilhoDireito() != null) {
                pi.push(p.getFilhoDireito());
            }
            if (p.getFilhoEsquerdo() != null) {
                pi.push(p.getFilhoEsquerdo());
            }
        }
    }
}