// Classe ABB para demonstrar a inserção, busca, remoção, atravessamentos etc.
// em uma Árvore Binária de Busca (ABB).

// Ledón, 2016/2017; Amilton Souza Martha, 2015/2017.

package testa_abb;

public class Testa_ABB {

    public static void main(String[] args) {   //p alunos

        System.out.println("\n\n\nAgora vamos criar uma ABB de objetos da classe Aluno (inserir pelos RGMs e percorrer em-ordem, ordenados):\n");
        ABB abb2 = new ABB();
        Aluno alA = new Aluno("888-8", "Caio", "M", 5.5f);
        Aluno alB = new Aluno("333-3", "Lara", "F", 9.8f);
        Aluno alC = new Aluno("666-6", "Vanessa", "F", 8.8f);
        Aluno alD = new Aluno("111-1", "Luiz", "M", 6.5f);
        Aluno alE = new Aluno("999-9", "Cláudia", "F", 9.5f); 
        Aluno alF = new Aluno("999-9", "Márcia", "F", 9.5f); 
        Aluno alG = new Aluno("999-9", "Leonardo", "M", 9.5f); 
        Aluno alH = new Aluno("999-9", "Juviscreuda", "F", 9.5f); 
        Aluno alI = new Aluno("999-9", "Rose", "F", 9.5f); 
        
        
        abb2.inserir(alA);
        abb2.inserir(alB);
        abb2.inserir(alC);
        abb2.inserir(alD);
        abb2.inserir(alE);
        abb2.inserir(alF);
        abb2.inserir(alG);
        abb2.inserir(alH);
        abb2.inserir(alI);
        
        abb2.preOrdemNaoRecursivo(abb2.getRaiz(), alI);
        
        abb2.listaAluno(alA);
        abb2.listaAluno(alB);
        abb2.listaAluno(alC);
        abb2.listaAluno(alD);
        abb2.listaAluno(alE);
        abb2.listaAluno(alF);
        abb2.listaAluno(alG);
        abb2.listaAluno(alH);
        abb2.listaAluno(alI);
        
        System.out.println("\n");
        
        for (int i = 0; i < abb2.a.size(); i++) {
            
            System.out.println(abb2.a.get(i));
        }
        
        System.out.println("\nA média das mulheres será:");
        
        abb2.calcularMedia();

    }
 
}